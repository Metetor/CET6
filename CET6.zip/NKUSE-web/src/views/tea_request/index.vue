<template>
  <div class="container2" style="min-height: 100%; padding-bottom: 100px;">
    <el-header>
      <div class="title-section">
        <h1 class="title">全国英语六级考试-教师阅卷报名</h1>
      </div>
    </el-header>
    <el-divider></el-divider>
    <div class="container" style="min-height: 100%; padding-bottom: 100px;">
    <el-form
      :model="ruleForm"
      :rules="rules"
      ref="ruleForm"
      label-width="100px"
      class="demo-border custom-form"
    >
      <el-form-item label="报考阅卷场次" prop="region">
        <el-select v-model="ruleForm.region" placeholder="请选择报考阅卷场次">
          <el-option label="第1届英语六级考试" value="1"></el-option>
          <el-option label="第2届英语六级考试" value="2"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="批阅题目">
        <el-select v-model="formInline.region" placeholder="请选择批阅题目">
          <el-option label="主观题1" value="1"></el-option>
          <el-option label="主观题2" value="2"></el-option>
        </el-select>
      </el-form-item>
      
      <el-checkbox-group v-model="checkList">
      <el-checkbox label="我已认真阅读阅卷注意事项，确认报名"></el-checkbox>
    </el-checkbox-group>
    <el-divider></el-divider>
      <el-form-item>
        <el-button type="primary" @click="submitForm">立即报名</el-button>
        <el-button @click="resetForm">重置</el-button>
      </el-form-item>
    </el-form>
  </div>
  </div>
</template>

<script>
export default {
  props: [],
  components: {},
  data() {
    return {
      checkList: ["选中且禁用", "我已认真阅读阅卷注意事项，确认报名"],
      formInline: {
        id: "",
        phone: "",
        email: "",
        region: "",
      },
      ruleForm: {
        name: "",
        region: "",
        date1: "",
        date2: "",
        delivery: false,
        type: [],
        resource: "",
        desc: "",
      },
      rules: {},
    };
  },
  watch: {},
  computed: {},
  beforeCreate() {},
  created() {},
  beforeMount() {},
  mounted() {},
  beforeUpdate() {},
  updated() {},
  destroyed() {},
  methods: {
    request() {},
    resetForm() {
      this.$message({
        message: "重置成功",
        type: "success",
      });
    },
    submitForm() {
      console.log("submit!");
    },
  },
  fillter: {},
};
</script>

<style scoped>
.container {
  justify-content: center;
  align-items: center;
  min-height: 100vh;
}
.title-section {
  background-color: rgba(48, 65, 86, 0.8);
  padding: 1px;
  text-align: center;
}
.title {
  color: white;
  font-weight: bold;
}
.demo-border {
  border: 1px grey dashed;
  min-height: 1rem;
  border-radius: 5px;
}

.custom-form {
  margin-top: 20px; /* 调整上边距 */
}
.container2 {
  margin-left: 20px; /* 调整左边距 */
}
</style>
