<template>
  <div>
    <h1 class="title">题目类型选择</h1>
    <el-select v-model="selectedType" placeholder="请选择题目类型" class="select">
      <el-option label="客观题" value="objective"></el-option>
      <el-option label="主观题" value="subjective"></el-option>
    </el-select>
    <el-button type="primary" @click="onButtonClick" size="big"
      >新建</el-button
    >
    <template v-if="selectedType === 'objective'">
      <h2 class="subtitle">客观题表格</h2>
      <el-table :data="objectiveData" class="table">
        <el-table-column prop="description" label="题目描述"></el-table-column>
        <el-table-column prop="optionA" label="选项A"></el-table-column>
        <el-table-column prop="optionB" label="选项B"></el-table-column>
        <el-table-column prop="optionC" label="选项C"></el-table-column>
        <el-table-column prop="optionD" label="选项D"></el-table-column>
        <el-table-column prop="answer" label="答案"></el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button type="primary" size="mini" @click="editObjective(scope.$index)">编辑</el-button>
            <el-button type="danger" size="mini" @click="confirmDeleteObjective(scope.$index)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </template>

    <template v-else-if="selectedType === 'subjective'">
      <h2 class="subtitle">主观题表格</h2>
      <el-table :data="subjectiveData" class="table">
        <el-table-column prop="description" label="题目描述"></el-table-column>
        <el-table-column prop="answer1" label="参考答案1"></el-table-column>
        <el-table-column prop="answer2" label="参考答案2"></el-table-column>
        <el-table-column prop="answer3" label="参考答案3"></el-table-column>
        <el-table-column prop="answer4" label="参考答案4"></el-table-column>
        <el-table-column prop="answer5" label="参考答案5"></el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button type="primary" size="mini" @click="editSubjective(scope.$index)">编辑</el-button>
            <el-button type="danger" size="mini" @click="confirmDeleteSubjective(scope.$index)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </template>
  </div>
</template>

<script>
export default {
  data() {
    return {
      selectedType: "objective",
      objectiveData: [
        {
          description: '题目描述1',
          optionA: 'A1',
          optionB: 'B1',
          optionC: 'C1',
          optionD: 'D1',
          answer: 'A',
        },
        {
          description: '题目描述2',
          optionA: 'A2',
          optionB: 'B2',
          optionC: 'C2',
          optionD: 'D2',
          answer: 'B',
        },{
          description: '题目描述3',
          optionA: 'A2',
          optionB: 'B2',
          optionC: 'C2',
          optionD: 'D2',
          answer: 'B',
        },{
          description: '题目描述4',
          optionA: 'A2',
          optionB: 'B2',
          optionC: 'C2',
          optionD: 'D2',
          answer: 'B',
        },{
          description: '题目描述5',
          optionA: 'A2',
          optionB: 'B2',
          optionC: 'C2',
          optionD: 'D2',
          answer: 'B',
        },{
          description: '题目描述6',
          optionA: 'A2',
          optionB: 'B2',
          optionC: 'C2',
          optionD: 'D2',
          answer: 'B',
        },{
          description: '题目描述7',
          optionA: 'A2',
          optionB: 'B2',
          optionC: 'C2',
          optionD: 'D2',
          answer: 'B',
        },{
          description: '题目描述8',
          optionA: 'A2',
          optionB: 'B2',
          optionC: 'C2',
          optionD: 'D2',
          answer: 'B',
        },
        {
          description: '题目描述2',
          optionA: 'A2',
          optionB: 'B2',
          optionC: 'C2',
          optionD: 'D2',
          answer: 'B',
        },{
          description: '题目描述3',
          optionA: 'A2',
          optionB: 'B2',
          optionC: 'C2',
          optionD: 'D2',
          answer: 'B',
        },{
          description: '题目描述4',
          optionA: 'A2',
          optionB: 'B2',
          optionC: 'C2',
          optionD: 'D2',
          answer: 'B',
        },{
          description: '题目描述5',
          optionA: 'A2',
          optionB: 'B2',
          optionC: 'C2',
          optionD: 'D2',
          answer: 'B',
        },{
          description: '题目描述6',
          optionA: 'A2',
          optionB: 'B2',
          optionC: 'C2',
          optionD: 'D2',
          answer: 'B',
        },{
          description: '题目描述7',
          optionA: 'A2',
          optionB: 'B2',
          optionC: 'C2',
          optionD: 'D2',
          answer: 'B',
        },{
          description: '题目描述8',
          optionA: 'A2',
          optionB: 'B2',
          optionC: 'C2',
          optionD: 'D2',
          answer: 'B',
        },
      ],
      subjectiveData: [
        {
          description: '题目描述3',
          answer1: '参考答案1',
          answer2: '参考答案2',
          answer3: '参考答案3',
          answer4: '参考答案4',
          answer5: '参考答案5',
        },
        {
          description: '题目描述4',
          answer1: '参考答案1',
          answer2: '参考答案2',
          answer3: '参考答案3',
          answer4: '参考答案4',
          answer5: '参考答案5',
        },,
        {
          description: '题目描述5',
          answer1: '参考答案1',
          answer2: '参考答案2',
          answer3: '参考答案3',
          answer4: '参考答案4',
          answer5: '参考答案5',
        },
        {
          description: '题目描述6',
          answer1: '参考答案1',
          answer2: '参考答案2',
          answer3: '参考答案3',
          answer4: '参考答案4',
          answer5: '参考答案5',
        },
        {
          description: '题目描述7',
          answer1: '参考答案1',
          answer2: '参考答案2',
          answer3: '参考答案3',
          answer4: '参考答案4',
          answer5: '参考答案5',
        },
        {
          description: '题目描述8',
          answer1: '参考答案1',
          answer2: '参考答案2',
          answer3: '参考答案3',
          answer4: '参考答案4',
          answer5: '参考答案5',
        },
        {
          description: '题目描述9',
          answer1: '参考答案1',
          answer2: '参考答案2',
          answer3: '参考答案3',
          answer4: '参考答案4',
          answer5: '参考答案5',
        },
        {
          description: '题目描述10',
          answer1: '参考答案1',
          answer2: '参考答案2',
          answer3: '参考答案3',
          answer4: '参考答案4',
          answer5: '参考答案5',
        },
        {
          description: '题目描述11',
          answer1: '参考答案1',
          answer2: '参考答案2',
          answer3: '参考答案3',
          answer4: '参考答案4',
          answer5: '参考答案5',
        }
      ],
    };
  },
  methods: {
    editObjective(index) {
      console.log('编辑客观题', index);
    },
    editSubjective(index) {
      console.log('编辑主观题', index);
    },
    confirmDeleteObjective(index) {
      this.$confirm('确定删除该客观题记录吗?', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.deleteObjective(index);
          this.$message.success('删除成功');
        })
        .catch(() => {
          this.$message.info('已取消删除');
        });
    },
    deleteObjective(index) {
      this.objectiveData.splice(index, 1);
    },
    confirmDeleteSubjective(index) {
      this.$confirm('确定删除该主观题记录吗?', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
        .then(() => {
          this.deleteSubjective(index);
          this.$message.success('删除成功');
        })
        .catch(() => {
          this.$message.info('已取消删除');
        });
    },
    deleteSubjective(index) {
      this.subjectiveData.splice(index, 1);
    },
  },
};
</script>

<style scoped>
.title {
  margin-bottom: 10px;
  border-bottom: 1px solid #ccc;
  padding-bottom: 5px;
}

.subtitle {
  margin-bottom: 10px;
  border-bottom: 1px solid #ccc;
  padding-bottom: 5px;
}

.select {
  margin-bottom: 20px;
}

.table {
  border: 1px solid #ccc;
  border-collapse: collapse;
  margin-bottom: 20px;
}

.table th,
.table td {
  border: 1px solid #ccc;
  padding: 5px;
  text-align: center;
}

.table .el-button {
  margin-right: 5px;
}
</style>
