package com.nku.stu.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.stereotype.Controller;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author lyh
 * @since 2023-05-19
 */
@Controller
@RequestMapping("/stu/quesSub")
public class QuesSubController {

}
