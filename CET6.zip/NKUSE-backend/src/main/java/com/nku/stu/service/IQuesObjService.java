package com.nku.stu.service;

import com.nku.stu.entity.QuesObj;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author lyh
 * @since 2023-05-19
 */
public interface IQuesObjService extends IService<QuesObj> {

}
